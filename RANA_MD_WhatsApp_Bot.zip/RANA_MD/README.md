# RANA MD WhatsApp Bot

Owner: Rana Furqan Rajput  
Owner number: 923003719761  
Menu image URL: https://postimg.cc/bSvZsvLB

## Setup
1. Install Node.js 20 or newer.
2. Extract this ZIP.
3. Run `npm install`
4. Run `npm start`
5. Scan the QR shown in terminal from WhatsApp > Linked devices.

## Important
- Do not upload or share the `auth_info_baileys` folder. It contains your private WhatsApp login session.
- This ZIP intentionally does not include session credentials.
- WhatsApp/Baileys can change; no one can honestly guarantee zero errors on every host. Test first in a separate deployment.
- Some commands require group-admin permissions or an external service and will explain when unavailable.
- Keep the bot compliant with WhatsApp terms and avoid spam or bulk unsolicited messaging.

## Commands
Use `.menu` or `.help`. Prefix defaults to `.`. There are 160+ registered command names/aliases.
