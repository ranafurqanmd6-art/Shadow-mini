const fs = require("fs");
const path = require("path");
const registry = require("./commands/registry.json");
const warnings = new Map();

function getText(msg) {
  const m = msg.message || {};
  return m.conversation || m.extendedTextMessage?.text ||
    m.imageMessage?.caption || m.videoMessage?.caption ||
    m.documentMessage?.caption || m.buttonsResponseMessage?.selectedButtonId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId || "";
}
function senderId(msg) { return (msg.key.participant || msg.key.remoteJid || "").split("@")[0].split(":")[0]; }
function jidFromNumber(s) { return String(s).replace(/\D/g, "") + "@s.whatsapp.net"; }
async function reply(sock, msg, text, extra={}) {
  return sock.sendMessage(msg.key.remoteJid, { text: String(text).slice(0, 4000), ...extra }, { quoted: msg });
}
function nums(s) { return s.trim().split(/[,\s]+/).filter(Boolean).map(Number); }
function menu() {
  const groups = {
    "GENERAL": ["menu","help","ping","alive","owner","about","runtime","prefix","support","rules","privacy","status","version"],
    "TEXT & TOOLS": ["say","reverse","upper","lower","count","wordcount","base64","hex","urlencode","morse","random","coinflip","dice","choose","calc","password","uuid","json","slug"],
    "MATH & CONVERTERS": ["add","subtract","multiply","divide","square","sqrt","power","percent","factorial","prime","fibonacci","c2f","f2c","km2mi","mi2km","kg2lb","lb2kg"],
    "GROUP ADMIN": ["groupid","myid","tagall","hidetag","admins","groupinfo","members","link","revoke","promote","demote","kick","warn","warnings","open","close","setsubject","setdesc"],
    "AI / DOWNLOAD / EXTERNAL": ["ai","ask","summarize","weather","news","translate","wiki","define","sticker","toimage","shorten"],
    "OWNER": ["ownerinfo","restart","shutdown","broadcast","setprefix","block","unblock"]
  };
  return "╭─「 RANA MD 」─╮\nOwner: Rana Furqan Rajput\nPrefix: .\n\n" +
    Object.entries(groups).map(([g,arr]) => `┌─「 ${g} 」\n${arr.map(x=>`.${x}`).join("  ")}`).join("\n\n") +
    `\n\nTotal registered commands: ${Object.keys(registry).length}\nMenu image: https://postimg.cc/bSvZsvLB`;
}
function helpGroup(prefix) {
  return {
    "__HELPADMIN__":"Group Admin: .groupinfo .members .admins .link .revoke .promote .demote .kick .tagall .hidetag .open .close .setsubject .setdesc",
    "__HELPDOWNLOAD__":"Download: Live media downloads need provider/API integrations. No fake downloader is enabled.",
    "__HELPAI__":"AI: .ai and .ask need a configured API provider and key; never share API keys in group chats.",
    "__HELPTOOLS__":"Tools: .calc .base64 .unbase64 .hex .urlencode .morse .password .uuid .json .slug .random",
    "__HELPOWNER__":"Owner: .ownerinfo .restart .shutdown .broadcast .setprefix .block .unblock (owner checks apply where implemented)"
  };
}
async function handleCommand(sock, msg, cfg) {
  const body = getText(msg).trim();
  if (!body.startsWith(cfg.PREFIX)) return;
  const parts = body.slice(cfg.PREFIX.length).trim().split(/\s+/);
  const command = (parts.shift() || "").toLowerCase();
  const args = parts.join(" ");
  if (!command || !registry[command]) return;
  const chat = msg.key.remoteJid;
  const sender = msg.key.participant || msg.key.remoteJid;
  const isGroup = chat.endsWith("@g.us");
  const isOwner = senderId(msg) === cfg.OWNER;
  const meta = isGroup ? await sock.groupMetadata(chat).catch(()=>null) : null;
  const admins = meta ? meta.participants.filter(p=>p.admin).map(p=>p.id) : [];
  const isAdmin = isOwner || admins.includes(sender);
  const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
  const text = args || "(empty)";
  const r = registry[command].response;
  const send = t => reply(sock,msg,t);
  if (command === "menu" || command === "help" || command === "commands") return send(menu());
  if (command === "runtime" || command === "uptime") return send(`⏱️ RANA MD is running. Process uptime: ${Math.floor(process.uptime())} seconds.`);
  if (command === "date" || command === "today") return send(new Date().toLocaleDateString());
  if (command === "time" || command === "now") return send(new Date().toLocaleTimeString());
  if (command === "say" || command === "echo") return send(args || "Usage: .say your text");
  if (command === "reverse") return send([...args].reverse().join(""));
  if (command === "upper") return send(args.toUpperCase());
  if (command === "lower") return send(args.toLowerCase());
  if (command === "titlecase") return send(args.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()));
  if (command === "count" || command === "charcount") return send(`Characters: ${args.length}\nWords: ${args.trim()?args.trim().split(/\s+/).length:0}`);
  if (command === "wordcount") return send(`Words: ${args.trim()?args.trim().split(/\s+/).length:0}`);
  if (command === "binary") return send([...args].map(c=>c.charCodeAt(0).toString(2).padStart(8,"0")).join(" "));
  if (command === "unbinary") { try { return send(args.trim().split(/\s+/).map(b=>String.fromCharCode(parseInt(b,2))).join("")); } catch { return send("Use: .unbinary 01001000 01101001"); } }
  if (command === "base64" || command === "base64encode") return send(Buffer.from(args).toString("base64"));
  if (command === "unbase64" || command === "base64decode") { try{return send(Buffer.from(args,"base64").toString("utf8"));}catch{return send("Invalid base64.");} }
  if (command === "hex") return send(Buffer.from(args).toString("hex"));
  if (command === "unhex") return send(Buffer.from(args,"hex").toString("utf8"));
  if (command === "urlencode" || command === "urlencode2") return send(encodeURIComponent(args));
  if (command === "urldecode" || command === "decodeurl") { try{return send(decodeURIComponent(args));}catch{return send("Invalid URL encoding.");} }
  if (command === "random" || command === "randomnumber") { let [a,b]=nums(args); if(!Number.isFinite(a))a=1;if(!Number.isFinite(b))b=100;if(a>b)[a,b]=[b,a];return send(String(Math.floor(Math.random()*(b-a+1))+a)); }
  if (command === "coinflip" || command === "coin") return send(Math.random()<.5?"🪙 Heads":"🪙 Tails");
  if (command === "dice" || command === "roll") return send("🎲 "+(1+Math.floor(Math.random()*6)));
  if (command === "choose" || command === "chooseone") {const opts=args.split("|").map(x=>x.trim()).filter(Boolean);return send(opts.length?opts[Math.floor(Math.random()*opts.length)]:"Usage: .choose tea | coffee");}
  if (["calc","add","subtract","multiply","divide","square","sqrt","power","percent","round","ceil","floor","abs","factorial","prime","isprime","evenodd","fibonacci","c2f","f2c","km2mi","mi2km","kg2lb","lb2kg","cm2in","in2cm","lcm","gcd","average","average2","median","median2","min","max","sort","sortnums"].includes(command)) {
    const n=nums(args);
    if(command==="calc") {
      if(!/^[\d\s()+\-*/%.]+$/.test(args)) return send("Only basic arithmetic characters are allowed. Example: .calc 12 * (3 + 2)");
      try { const tokens=args.match(/\d+(?:\.\d+)?|[()+\-*/%]/g)||[]; if(tokens.join("")!==args.replace(/\s/g,"")) return send("Invalid expression."); const val=Function('"use strict";return ('+args+')')(); return send(Number.isFinite(val)?String(val):"Invalid result."); } catch { return send("Invalid calculation.");}
    }
    let x=n[0], y=n[1], out;
    if(!Number.isFinite(x)) return send(`Usage: .${command} number [number]`);
    switch(command){
      case "add": out=n.reduce((a,b)=>a+b,0);break;
      case "subtract": out=x-y;break; case "multiply":out=n.reduce((a,b)=>a*b,1);break;
      case "divide": if(y===0)return send("Cannot divide by zero.");out=x/y;break;
      case "square":out=x*x;break;case "sqrt":if(x<0)return send("Use a non-negative number.");out=Math.sqrt(x);break;
      case "power":out=Math.pow(x,y);break;case "percent":out=(x/y)*100;break;
      case "round":out=Math.round(x);break;case "ceil":out=Math.ceil(x);break;case "floor":out=Math.floor(x);break;case "abs":out=Math.abs(x);break;
      case "factorial":if(!Number.isInteger(x)||x<0||x>170)return send("Use an integer from 0 to 170.");out=1;for(let i=2;i<=x;i++)out*=i;break;
      case "prime":case "isprime":out=x>=2&&Number.isInteger(x);for(let i=2;out&&i<=Math.sqrt(x);i++)if(x%i===0)out=false;break;
      case "evenodd":out=x%2===0?"Even":"Odd";break;
      case "fibonacci":{let count=Math.max(1,Math.min(40,Math.floor(x))),a=0,b=1,arr=[];for(let i=0;i<count;i++){arr.push(a);[a,b]=[b,a+b]}out=arr.join(", ");break;}
      case "c2f":out=x*9/5+32;break;case "f2c":out=(x-32)*5/9;break;
      case "km2mi":out=x*0.621371;break;case "mi2km":out=x/0.621371;break;case "kg2lb":out=x*2.20462;break;case "lb2kg":out=x/2.20462;break;case "cm2in":out=x/2.54;break;case "in2cm":out=x*2.54;break;
      case "gcd":{let a=Math.abs(x),b=Math.abs(y);while(b)[a,b]=[b,a%b];out=a;break;}
      case "lcm":{let a=Math.abs(x),b=Math.abs(y),g=a,h=b;while(h)[g,h]=[h,g%h];out=(a*b)/(g||1);break;}
      case "average":case "average2":out=n.reduce((a,b)=>a+b,0)/n.length;break;
      case "median":case "median2":{let a=[...n].sort((a,b)=>a-b);out=a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2;break;}
      case "min":out=Math.min(...n);break;case "max":out=Math.max(...n);break;case "sort":case "sortnums":out=n.sort((a,b)=>a-b).join(", ");break;
    }
    return send(String(out));
  }
  if(command==="password"){const len=Math.max(8,Math.min(64,parseInt(args)||16));const chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%";let p="";for(let i=0;i<len;i++)p+=chars[Math.floor(Math.random()*chars.length)];return send("Generated password (keep private): "+p);}
  if(command==="uuid") return send(require("crypto").randomUUID());
  if(command==="timestamp") return send(String(Math.floor(Date.now()/1000)));
  if(command==="quote") return send(["Small steps still move you forward.","Consistency beats intensity.","Learn something new every day."][Math.floor(Math.random()*3)]);
  if(command==="joke") return send("Why did the computer get cold? It left its Windows open. 😄");
  if(command==="fact") return send("Honeybees communicate food locations through a movement pattern called the waggle dance.");
  if(command==="motivate"||command==="motd") return send("Keep learning, stay kind, and take one step at a time. 🌟");
  if(command==="truth") return send("Truth: What is one skill you'd like to learn?");
  if(command==="dare") return send("Dare: Give someone a sincere compliment.");
  if(command==="riddle") return send("What has keys but can't open locks? A piano.");
  if(command==="compliment") return send("You deserve credit for the effort you put in. ✨");
  if(command==="apology") return send("I'm sorry for what happened. I understand it affected you, and I'll try to do better.");
  if(command==="thanks") return send("Thank you! I really appreciate it. 🙏");
  if(command==="groupid") return send(chat);
  if(command==="myid") return send(sender);
  if(["tagall","hidetag","admins","groupinfo","members","link","revoke","promote","demote","kick","add","open","close","setsubject","setdesc"].includes(command) && !isGroup) return send("This command only works in groups.");
  if(["tagall","hidetag","revoke","promote","demote","kick","add","open","close","setsubject","setdesc"].includes(command) && !isAdmin) return send("Only group admins or the bot owner can use this command.");
  if(command==="admins") return send("Group admins:\n"+admins.map(a=>"• @"+a.split("@")[0]).join("\n"));
  if(command==="groupinfo") return send(`Name: ${meta?.subject||"Unknown"}\nMembers: ${meta?.participants?.length||0}\nID: ${chat}`);
  if(command==="members") return send(`Members: ${meta?.participants?.length||0}`);
  if(command==="link"){if(!isAdmin)return send("Admin permission required.");try{return send("https://chat.whatsapp.com/"+(await sock.groupInviteCode(chat)));}catch{return send("Could not get invite link.");}}
  if(command==="revoke"){try{await sock.groupRevokeInvite(chat);return send("Group invite link reset.");}catch{return send("Could not reset link.");}}
  if(command==="promote"||command==="demote"||command==="kick"){if(!quotedParticipant)return send("Reply to a member's message first.");try{await sock.groupParticipantsUpdate(chat,[quotedParticipant],command==="promote"?"promote":command==="demote"?"demote":"remove");return send(`Done: ${command} request sent.`);}catch{return send("Action failed. Check bot admin permissions.");}}
  if(command==="add"){const num=args.replace(/\D/g,"");if(num.length<8)return send("Usage: .add countrycode+number");try{const res=await sock.groupParticipantsUpdate(chat,[jidFromNumber(num)],"add");return send(JSON.stringify(res));}catch{return send("Could not add member. Privacy settings may prevent it.");}}
  if(command==="open"||command==="close"){try{await sock.groupSettingUpdate(chat,command==="open"?"not_announcement":"announcement");return send(`Group is now ${command==="open"?"open":"closed"} for members.`);}catch{return send("Could not change group setting.");}}
  if(command==="setsubject"){if(!args)return send("Usage: .setsubject new group name");try{await sock.groupUpdateSubject(chat,args);return send("Group name updated.");}catch{return send("Could not update group name.");}}
  if(command==="setdesc"){if(!args)return send("Usage: .setdesc new description");try{await sock.groupUpdateDescription(chat,args);return send("Group description updated.");}catch{return send("Could not update description.");}}
  if(command==="tagall"||command==="hidetag"){const mentions=meta.participants.map(p=>p.id);const message=args||"Attention everyone";return sock.sendMessage(chat,{text:message+(command==="tagall"?"\n"+mentions.map(x=>"@"+x.split("@")[0]).join(" "):""),mentions},{quoted:msg});}
  if(command==="warn"){const who=quotedParticipant||sender;warnings.set(who,(warnings.get(who)||0)+1);return send(`Warning recorded in memory. Count: ${warnings.get(who)} (clears on restart).`);}
  if(command==="warnings"){const who=quotedParticipant||sender;return send(`Warnings: ${warnings.get(who)||0} (in-memory only).`);}
  if(command==="clearwarn"){if(!isOwner)return send("Owner only.");const who=quotedParticipant||sender;warnings.delete(who);return send("Warnings cleared.");}
  if(command==="summarize"){return send(args.length<40?args:"Quick summary: "+args.split(/[.!?]\s/).slice(0,3).join(". "));}
  if(command==="todo"||command==="list"){return send("Checklist:\n"+args.split(",").filter(Boolean).map(x=>"☐ "+x.trim()).join("\n"));}
  if(command==="poll") return send("📊 POLL\n"+args.split("|").map((x,i)=>`${i}. ${x.trim()}`).join("\n")+"\nReply with your choice.");
  if(command==="emoji") return send("😀 😎 🤖 🎉 ❤️ 🔥 🌟 🙌");
  if(command==="emojimix") return send("✨🤖✨  🔥💯🔥  🌙⭐🌙");
  if(command==="clap") return send(args.split(/\s+/).join(" 👏 "));
  if(command==="mock") return send([...args].map((c,i)=>i%2?c.toLowerCase():c.toUpperCase()).join(""));
  if(command==="spoiler") return send("||"+args+"||");
  if(command==="quoteformat"||command==="quoteformat") return send("❝ "+args+" ❞");
  if(command==="slug") return send(args.toLowerCase().trim().replace(/[^a-z0-9\s-]/g,"").replace(/\s+/g,"-"));
  if(command==="palindrome") return send((args.toLowerCase().replace(/[^a-z0-9]/g,"")===args.toLowerCase().replace(/[^a-z0-9]/g,"").split("").reverse().join(""))?"Palindrome":"Not a palindrome");
  if(command==="anagram"){const [a,b]=args.split("|");if(!a||!b)return send("Usage: .anagram word1 | word2");const norm=s=>s.toLowerCase().replace(/\s/g,"").split("").sort().join("");return send(norm(a)===norm(b)?"Anagrams":"Not anagrams");}
  if(command==="initials") return send(args.split(/\s+/).filter(Boolean).map(w=>w[0].toUpperCase()).join(""));
  if(command==="acronym") return send(args.split(/\s+/).filter(Boolean).map(w=>w[0].toUpperCase()).join(""));
  if(command==="trim") return send(args.replace(/\s+/g," ").trim());
  if(command==="lines") return send("Lines: "+(args?args.split(/\r?\n/).length:0));
  if(command==="json"){try{return send(JSON.stringify(JSON.parse(args),null,2));}catch{return send("Invalid JSON. Usage: .json {\"key\":1}");}}
  if(command==="escape") return send(JSON.stringify(args).slice(1,-1));
  if(command==="unescape"){try{return send(JSON.parse('"'+args+'"'));}catch{return send("Invalid escaped text.");}}
  if(command==="randomcolor") return send("#"+Math.floor(Math.random()*16777215).toString(16).padStart(6,"0").toUpperCase());
  if(command==="bytes"){let b=Number(args);if(!Number.isFinite(b)||b<0)return send("Usage: .bytes 2048");let u=["B","KB","MB","GB","TB"],i=0;while(b>=1024&&i<u.length-1){b/=1024;i++}return send(`${b.toFixed(2)} ${u[i]}`);}
  if(command==="bmi"){const [kg,cm]=nums(args);if(!(kg>0&&cm>0))return send("Usage: .bmi weight_kg height_cm (BMI is only a rough screening measure, not a diagnosis).");return send("BMI: "+(kg/((cm/100)**2)).toFixed(1)+" (adult categories may not apply to teens).");}
  if(command==="roman"){let n=Number(args);if(!Number.isInteger(n)||n<1||n>3999)return send("Use an integer from 1 to 3999.");let out="",vals=[[1000,"M"],[900,"CM"],[500,"D"],[400,"CD"],[100,"C"],[90,"XC"],[50,"L"],[40,"XL"],[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];for(const [v,s] of vals)while(n>=v){out+=s;n-=v}return send(out);}
  if(command==="ownerinfo"||command==="owner") return send("👑 Owner: Rana Furqan Rajput\n📱 +923003719761");
  if(command==="restart"||command==="shutdown"||command==="broadcast"||command==="setprefix"||command==="block"||command==="unblock"){
    if(!isOwner)return send("Owner only.");
    const msgText={restart:"Restart the service from your hosting dashboard; command does not terminate the process.",shutdown:"Stop the service from your hosting dashboard.",broadcast:"Broadcast sending is intentionally disabled to prevent unsolicited bulk messaging.",setprefix:"Prefix is configured in index.js (PREFIX). Restart after changing it.",block:"Use WhatsApp's own controls to manage blocked contacts.",unblock:"Use WhatsApp's own controls to manage blocked contacts."}[command];
    return send(msgText);
  }
  if(command==="menuimage") return send("Menu image URL: https://postimg.cc/bSvZsvLB");
  const helper=helpGroup()[r];
  if(helper) return send(helper);
  if(r==="__RESTART__"||r==="__SHUTDOWN__"||r==="__BROADCAST__"||r==="__SETPREFIX__"||r==="__BLOCK__"||r==="__UNBLOCK__") return send("Owner-only setting; see README.md.");
  if(r==="__SAY__") return send(args);
  if(r==="__REVERSE__") return send([...args].reverse().join(""));
  if(r==="__UPPER__") return send(args.toUpperCase());
  if(r==="__LOWER__") return send(args.toLowerCase());
  if(r==="__TITLE__") return send(args.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()));
  if(r==="__COUNT__") return send(`Characters: ${args.length}\nWords: ${args.trim()?args.trim().split(/\s+/).length:0}`);
  if(r==="__WORDCOUNT__") return send(`Words: ${args.trim()?args.trim().split(/\s+/).length:0}`);
  if(r==="__BINARY__") return send([...args].map(c=>c.charCodeAt(0).toString(2).padStart(8,"0")).join(" "));
  if(r==="__BASE64__") return send(Buffer.from(args).toString("base64"));
  if(r==="__UNBASE64__") return send(Buffer.from(args,"base64").toString("utf8"));
  if(r==="__HEX__") return send(Buffer.from(args).toString("hex"));
  if(r==="__URLENCODE__") return send(encodeURIComponent(args));
  if(r==="__URLDECODE__") {try{return send(decodeURIComponent(args))}catch{return send("Invalid URL encoding.")}}
  if(r==="__MORSE__"){const map={"A":".-","B":"-...","C":"-.-.","D":"-..","E":".","F":"..-.","G":"--.","H":"....","I":"..","J":".---","K":"-.-","L":".-..","M":"--","N":"-.","O":"---","P":".--.","Q":"--.-","R":".-.","S":"...","T":"-","U":"..-","V":"...-","W":".--","X":"-..-","Y":"-.--","Z":"--.."," ":"/"};return send(args.toUpperCase().split("").map(c=>map[c]||c).join(" "))}
  if(r==="__UNMORSE__") return send("Morse decoding is not available for this input yet.");
  if(r==="__RANDOM__") return send(String(1+Math.floor(Math.random()*100)));
  if(r==="__COIN__") return send(Math.random()<.5?"Heads":"Tails");
  if(r==="__DICE__") return send(String(1+Math.floor(Math.random()*6)));
  if(r==="__CHOOSE__"){const a=args.split("|").map(x=>x.trim()).filter(Boolean);return send(a.length?a[Math.floor(Math.random()*a.length)]:"Use: .choose option1 | option2")}
  if(r==="__CALC__") return send("Use .calc with basic arithmetic, e.g. .calc 2 + 2");
  if(r==="__SQUARE__") return send(String(Number(args)**2));
  if(r==="__SQRT__") return send(String(Math.sqrt(Number(args))));
  if(r==="__POWER__"){const [a,b]=nums(args);return send(String(a**b))}
  if(r==="__PERCENT__"){const [a,b]=nums(args);return send(String(a/b*100)+"%")}
  if(r==="__FACTORIAL__"){let n=Number(args);if(!Number.isInteger(n)||n<0||n>170)return send("Use integer 0-170");let x=1;for(let i=2;i<=n;i++)x*=i;return send(String(x))}
  if(r==="__PRIME__"){let n=Number(args),p=n>=2&&Number.isInteger(n);for(let i=2;p&&i<=Math.sqrt(n);i++)if(n%i===0)p=false;return send(String(p))}
  if(r==="__EVENODD__")return send(Number(args)%2===0?"Even":"Odd");
  if(r==="__FIB__"){let n=Math.max(1,Math.min(40,Number(args)||10)),a=0,b=1,o=[];for(let i=0;i<n;i++){o.push(a);[a,b]=[b,a+b]}return send(o.join(", "))}
  if(r==="__C2F__")return send(String(Number(args)*9/5+32));
  if(r==="__F2C__")return send(String((Number(args)-32)*5/9));
  if(r==="__KM2MI__")return send(String(Number(args)*0.621371));
  if(r==="__MI2KM__")return send(String(Number(args)/0.621371));
  if(r==="__KG2LB__")return send(String(Number(args)*2.20462));
  if(r==="__LB2KG__")return send(String(Number(args)/2.20462));
  if(r==="__CM2IN__")return send(String(Number(args)/2.54));
  if(r==="__IN2CM__")return send(String(Number(args)*2.54));
  if(r==="__TIMESTAMP__")return send(String(Math.floor(Date.now()/1000)));
  if(r==="__DATE__")return send(new Date().toLocaleDateString());
  if(r==="__TIME__")return send(new Date().toLocaleTimeString());
  if(r==="__UUID__")return send(require("crypto").randomUUID());
  if(r==="__COLOR__")return send("#"+Math.floor(Math.random()*16777215).toString(16).padStart(6,"0"));
  if(r==="__SUMMARIZE__")return send(args.length<40?args:"Summary: "+args.split(/[.!?]\s/).slice(0,3).join(". "));
  if(r==="__TODO__")return send(args.split(",").filter(Boolean).map(x=>"☐ "+x.trim()).join("\n"));
  if(r==="__POLL__")return send("📊 Poll\n"+args.split("|").map((x,i)=>`${i+1}. ${x.trim()}`).join("\n"));
  if(r==="__EMOJI__")return send("😀 😎 🤖 🎉 ❤️ 🔥 🌟 🙌");
  if(r==="__EMOJIMIX__")return send("✨🤖✨ 🔥💯🔥 🌙⭐🌙");
  if(r==="__CLAP__")return send(args.split(/\s+/).join(" 👏 "));
  if(r==="__MOCK__")return send([...args].map((c,i)=>i%2?c.toLowerCase():c.toUpperCase()).join(""));
  if(r==="__SPOILER__")return send("||"+args+"||");
  if(r==="__SLUG__")return send(args.toLowerCase().trim().replace(/[^a-z0-9\s-]/g,"").replace(/\s+/g,"-"));
  if(r==="__PALINDROME__"){const s=args.toLowerCase().replace(/[^a-z0-9]/g,"");return send(s===s.split("").reverse().join("")?"Palindrome":"Not a palindrome")}
  if(r==="__ANAGRAM__"){const [a,b]=args.split("|");if(!a||!b)return send("Use: .anagram word1 | word2");const f=s=>s.toLowerCase().replace(/\s/g,"").split("").sort().join("");return send(f(a)===f(b)?"Anagrams":"Not anagrams")}
  if(r==="__INITIALS__"||r==="__ACRONYM__")return send(args.split(/\s+/).filter(Boolean).map(w=>w[0].toUpperCase()).join(""));
  if(r==="__TRIM__")return send(args.replace(/\s+/g," ").trim());
  if(r==="__LINES__")return send("Lines: "+(args?args.split(/\r?\n/).length:0));
  if(r==="__JSON__"){try{return send(JSON.stringify(JSON.parse(args),null,2))}catch{return send("Invalid JSON")}}
  if(r==="__ESCAPE__")return send(JSON.stringify(args).slice(1,-1));
  if(r==="__UNESCAPE__"){try{return send(JSON.parse('"'+args+'"'))}catch{return send("Invalid escaped text")}}
  if(r==="__AVERAGE__"){const a=nums(args);return send(String(a.reduce((x,y)=>x+y,0)/a.length))}
  if(r==="__MEDIAN__"){const a=nums(args).sort((x,y)=>x-y);return send(String(a.length%2?a[(a.length-1)/2]:(a[a.length/2-1]+a[a.length/2])/2))}
  if(r==="__MIN__")return send(String(Math.min(...nums(args))));
  if(r==="__MAX__")return send(String(Math.max(...nums(args))));
  if(r==="__SORT__")return send(nums(args).sort((x,y)=>x-y).join(", "));
  if(r==="__SHUFFLE__"){const a=args.split(/\s+/);for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return send(a.join(" "))}
  if(r==="__DEDUPE__")return send([...new Set(args.split(/\s+/))].join(" "));
  if(r==="__ROMAN__")return send("Use .roman 2026 to convert a number.");
  if(r==="__GROUPLINK__")return send("Use .link in a group as an admin.");
  if(r==="__PROMOTE__"||r==="__DEMOTE__"||r==="__KICK__")return send("Reply to a member message, then use this command.");
  if(r==="__TAGALL__"||r==="__HIDETAG__")return send("Use this in a group; admin permission is required.");
  if(r==="__GROUPINFO__")return send("Use .groupinfo inside a group.");
  if(r==="__MEMBERS__")return send("Use .members inside a group.");
  if(r==="__ADMINS__")return send("Use .admins inside a group.");
  if(r==="__OPEN__"||r==="__CLOSE__")return send("Use in a group as an admin.");
  if(r==="__SUBJECT__"||r==="__DESC__")return send("Provide the new value after the command.");
  if(r==="__WARN__"||r==="__WARNINGS__"||r==="__CLEARWARN__")return send("Use .warn by replying to a member.");
  if(r==="__BROADCAST__")return send("Broadcast disabled to prevent unsolicited bulk messages.");
  if(r==="__SETPREFIX__")return send("Change PREFIX in index.js and restart.");
  if(r==="__BLOCK__"||r==="__UNBLOCK__")return send("Manage blocked contacts in WhatsApp settings.");
  if(r==="__RESTART__"||r==="__SHUTDOWN__")return send("Use your hosting dashboard to restart or stop the process.");
  return send(typeof r==="string"&&!r.startsWith("__")?r:`Command .${command} is registered. This feature needs extra configuration; see README.md.`);
}
module.exports = { handleCommand };
